#include "SeqList.hpp"
#include <iostream>
#include <fstream>

using std::endl;
using std::ios;
using std::cout;
using std::ofstream;
using std::ifstream;

class Rate
{
    friend ofstream& operator<<(ofstream&, const Rate&);
public:
    Rate();
    Rate(int y, double r)
        :years(y),rate(r)
        {
        }
    int years;
    double rate;
};

ofstream& operator<<(ofstream& output, const Rate& mRate)
{
    output << mRate.years << " " << mRate.rate << endl;
    return output;
}

int main()
{
    ofstream outFile("ratedata.dat", ios::out);
    ifstream inFile("ratedata.dat", ios::in);

    SeqList<Rate> rateTable;
    
    rateTable.insert(Rate(1, 0.01), 0);
    rateTable.insert(Rate(2, 0.02), 0);
    rateTable.insert(Rate(3, 0.03), 0);
    rateTable.insert(Rate(4, 0.04), 0);

    for (SeqList<Rate>::Node* p = rateTable.first(); p; p = rateTable.nextPos(p))
    {
        outFile << p -> data;
    }

    int yr = 4;
    double tot = 10000;
    double gain = 0;
    for (SeqList<Rate>::Node* p = rateTable.first(); p; p = rateTable.nextPos(p))
    {
        if (p -> data.years <= 4)
        {
            gain += tot * p -> data.rate;
        }
    }

    cout << tot + gain << endl;
    
    return 0;
}
