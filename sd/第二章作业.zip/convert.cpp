#include <iostream>
#include "ListStack.hpp"

using std::cout;
using std::endl;
using std::cin;

int main(int argc, char *argv[])
{
    ListStack<int> mS;
    int base;
    int num;

    cout << "你要转成几进制？" << endl;
    cin >> base;
    cout << "你要转哪个数？" << endl;
    cin >> num;

    while (num)
    {
        mS.push(num % base);
        num = num / base;
    }

    while (!mS.isEmpty())
    {
        cout << mS.pop();
    }

    cout<<endl;
    
    return 0;
}
