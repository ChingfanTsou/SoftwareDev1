#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int main(int argc, char *argv[])
{
    int n;
    int num[100][100];
    int row[100];
    int col[100];

    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            cin >> num[i][j];
        }
    }

    for (int i = 0; i < n; ++i)
    {
        int max = -0x7fffffff;
        for (int j = 0; j < n; ++j)
        {
            if (max < num[i][j])
            {
                max = num[i][j];
                row[i] = j;
            }
        }
    }

    for (int j = 0; j < n; ++j)
    {
        int max = -0x7fffffff;
        for (int i = 0; i < n; ++i)
        {
            if (max < num[i][j])
            {
                max = num[i][j];
                col[j] = i;
            }
        }
    }

    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            if (row[i] == j && col[j] == i)
            {
                cout << i << "," << j << "is the point" << endl;
            }
        }
    }


    return 0;
}
