#include <iostream>
#include <string>
#include <cstdlib>
#include "ListStack.hpp"

using std::string;
using std::cout;
using std::endl;
using std::cin;

int main(int argc, char *argv[])
{
    ListStack<char> mS;
    string exp;

    cout << "Please input an expression" << endl;
    cin >> exp;

    for (string::iterator p = exp.begin(); p != exp.end(); p++)
    {
        switch (*p)
        {
        case '{':
        case '[':
        case '(':
            mS.push(*p);
            break;
        case '}':
            if (mS.isEmpty() || mS.getTop() != '{')
            {
                cout << "Illegal Expression!" << endl;
                exit(1);
            }
            else
            {
                mS.pop();
            }
            break;
        case ')':
            if (mS.isEmpty() || mS.getTop() != '(')
            {
                cout << "Illegal Expression!" << endl;
                exit(1);
            }
            else
            {
                mS.pop();
            }
            break;
        case ']':
            if (mS.isEmpty() || mS.getTop() != '[')
            {
                cout << "Illegal Expression!" << endl;
                exit(1);
            }
            else
            {
                mS.pop();
            }
            break;
        }
    }

    cout << "Legal Expression!" << endl;

    return 0;
}
