#include <iostream>
#include "SeqVec.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>

using std::endl;
using std::ios;
using std::cout;
using std::ofstream;
using std::ifstream;
using std::string;
using std::sort;
using std::ostream;

class People
{
public:
    People(const string& n, const string& t)
        :name(n),telnum(t)
        {
        }
    People(const People& so)
        :name(so.name),telnum(so.telnum)
        {
        }
    People()
        {
        }
    string name;
    string telnum;
};

class AddBook : public SeqVec<People>
{
    friend void sortByName(AddBook&);
};

bool cmp(People a, People b)
{
    return (a.name < b.name);
}

void sortByName(AddBook& mAddBook)
{
    sort(mAddBook.data, mAddBook.data + mAddBook.lastEle + 1, cmp);
}

ofstream& operator<<(ofstream& output, People so)
{
    output << so.name << " " << so.telnum << endl;
}

ostream& operator<<(ostream& output, People so)
{
    output << so.name << " " << so.telnum << endl;
}

int main()
{
    AddBook mAddBook;
    
    mAddBook.insert(People("a", "1234567"), 0);
    mAddBook.insert(People("d", "2234567"), 0);
    mAddBook.insert(People("c", "3234567"), 0);
    mAddBook.insert(People("b", "4234567"), 0);
    mAddBook.insert(People("f", "5234567"), 0);

    sortByName(mAddBook);

    ofstream outFile("addressbook.dat", ios::out);
    
    for (int i = mAddBook.first(); i <= mAddBook.last(); ++i)
    {
        outFile << mAddBook.findByPos(i);
        cout << mAddBook.findByPos(i);
    }

    mAddBook.delByPos(2);
    
    return 0;
}
