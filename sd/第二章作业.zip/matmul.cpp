#include <iostream>

using std::cin;
using std::cout;
using std::endl;

int con(int* num, int x, int y)
{
    if (x >= y)
    {
        return num[x*(x+1)/2+y];
    }
    else
    {
        return num[y*(y+1)/2+x];
    }
}
int main(int argc, char *argv[])
{
    int n;
    int A[100];
    int B[100];
    int C[10][10];

    cin >> n;
    for (int i = 0; i < n; ++i)
    {
        cin >> A[i];
    }

    for (int i = 0; i < n; ++i)
    {
        cin >> B[i];
    }

    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j)
        {
            for (int k = 0; k < n; ++k)
            {
                C[i][j] = con(A, i, k) * con(B, k, j);
            }
        }
    return 0;
}
