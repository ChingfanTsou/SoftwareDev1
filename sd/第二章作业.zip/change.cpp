#include <iostream>
#include "QueueList.hpp"
#include "ListStack.hpp"

using std::cout;
using std::endl;

int main(int argc, char *argv[])
{
    QueueList<int> mQ;
    ListStack<int> mS;

    for (int i = 10; i >= 1; --i)
    {
        mS.push(i);
    }

    while (!mS.isEmpty())
    {
        mQ.enQueue(mS.pop());
    }

    for (int i = 1; i <= 10; ++i)
    {
        if (i & 1)
        {
            mS.push(mQ.deQueue());
        }
        else
        {
            mQ.enQueue(mQ.deQueue());
        }
    }

    while (!mQ.isEmpty())
    {
        mS.push(mQ.deQueue());
    }

    while (!mS.isEmpty())
    {
        cout << mS.pop() << endl;
    }
    
    return 0;
}
