#include <cstdio>
#include <cstring>

int main(int argc, char *argv[])
{
    int next[100];
    next[1] = 0;
    int p = 0;
    char s[100];

    scanf("%s", s + 1);
    
    for (int i = 2; i <= strlen(s); ++i)
    {
        while (p && s[p + 1] != s[p])
        {
            p = next [p];
        }
        if (s[p + 1] = s[p])
        {
            ++p;
        }
        next[i] = p;
    }

    return 0;
}
